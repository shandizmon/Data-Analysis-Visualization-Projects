
# Analysis

### Observed Trend 1:
Cities loacated close to latitude 0 (equator) have the highest temprature and as you get farther from    equator temperature decreases. Please note that these tempretaure are collected in the hottest period of the year and conclusively the temperature range is less than if we had collected data in winter or spring.

### Observed Trend 2: 
Cities loacated close to latitude 0 (equator) have a higher humidity which is probably due to higher water evaporation rate. Also it looks for the cities in the southern hemisphere the farthest ones from equator have higher humidity.

### Observed Trend 3: 
Laditude does not seem to have a correlation to wind speed and cloudiness.


```python
# Dependencies
import requests
import pandas as pd
import json
from pprint import pprint
from citipy import citipy
from random import uniform
import matplotlib.pyplot as plt

# Google developer API key
from apikeys import api_key as gkey
```


```python
# geocoordinates

def newpoint1():
    return uniform(-90.0,0), uniform(-180.0,180.0)

def newpoint2():
    return uniform(0,90), uniform(-180.0,180.0)

coordinates = []
points = (newpoint1() for x in range(300))
for point in points:
    coordinates.append(point)

points = (newpoint2() for x in range(300))
for point in points:
    coordinates.append(point)
    
```


```python
cities = []
for coordinate_pair in coordinates:
    lat, lon = coordinate_pair
    cities.append((citipy.nearest_city(lat, lon).city_name))
    
```


```python
# list for response results
lat = []
temp = []
humidity = []
clouds = []
wind = []

api_params = {
    'appid': gkey,
    'units': 'imperial',
}

# Build URL
base_url = "http://api.openweathermap.org/data/2.5/weather"

# Get weather information in JSON format
for city in cities:
    # Adding "null" value for the cities which don't have value by "try" and "except"
    try:
        api_params['q']=city
        weather_response = requests.get(base_url, params=api_params).json()
    
        lat.append(weather_response['coord']['lat'])
        temp.append(weather_response['main']['temp_max'])
        humidity.append(weather_response['main']['humidity'])
        clouds.append(weather_response['clouds']['all'])
        wind.append(weather_response['wind']['speed'])
    except:
        lat.append('null')
        temp.append('null')
        humidity.append('null')
        clouds.append('null')
        wind.append('null')



# build a dataframe from the cities, lat, Temperature, Humidity (%), Cloudiness (%),Wind Speed (mph) lists
weather_data = {"City": cities, "Latitude": lat, "Max Temperature (F)": temp, "Humidity (%)": humidity, 
                "Cloudiness (%)": clouds, "Wind Speed (mph)": wind}
df_weather_data = pd.DataFrame(weather_data)
df_weather_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>City</th>
      <th>Cloudiness (%)</th>
      <th>Humidity (%)</th>
      <th>Latitude</th>
      <th>Max Temperature (F)</th>
      <th>Wind Speed (mph)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>pisco</td>
      <td>90</td>
      <td>93</td>
      <td>-13.71</td>
      <td>60.8</td>
      <td>3.36</td>
    </tr>
    <tr>
      <th>1</th>
      <td>te anau</td>
      <td>92</td>
      <td>98</td>
      <td>-45.41</td>
      <td>37.88</td>
      <td>1.36</td>
    </tr>
    <tr>
      <th>2</th>
      <td>mafeteng</td>
      <td>0</td>
      <td>74</td>
      <td>-29.82</td>
      <td>29.06</td>
      <td>3.71</td>
    </tr>
    <tr>
      <th>3</th>
      <td>ushuaia</td>
      <td>0</td>
      <td>99</td>
      <td>-54.81</td>
      <td>31.58</td>
      <td>16.24</td>
    </tr>
    <tr>
      <th>4</th>
      <td>rikitea</td>
      <td>88</td>
      <td>100</td>
      <td>-23.12</td>
      <td>73.16</td>
      <td>16.24</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Removing the null value rows from the dataframe
df_weather_data = df_weather_data[df_weather_data.Latitude!='null']
df_weather_data['City'].count()
```




    534




```python
# Build the Temperature scatter plot for dataframe
plt.figure(figsize= (12,5))
plt.scatter(df_weather_data["Latitude"], df_weather_data["Max Temperature (F)"], marker="o")

# Incorporate the other graph properties
plt.ylim(-100,150)
plt.xlim(-80,100)
plt.title("City Latitude vs. Max Temperature (06/18/2018)")
plt.ylabel("Max Temperature (Fahrenheit)")
plt.xlabel("Latitude")
plt.grid(True)

# Save the figure
plt.savefig("CityLatitudevsMaxTemperature.png")

# Show plot
plt.show()
```


![png](output_6_0.png)



```python
# Build the Humidity scatter plot for dataframe
plt.figure(figsize= (12,5))
plt.scatter(df_weather_data["Latitude"], df_weather_data["Humidity (%)"], marker="o")

# Incorporate the other graph properties
plt.ylim(-20,120)
plt.xlim(-80,100)
plt.title("City Latitude vs. Humidity (06/18/2018)")
plt.ylabel("Humidity (%)")
plt.xlabel("Latitude")
plt.grid(True)

# Save the figure
plt.savefig("CityLatitudevsHumidity.png")

# Show plot
plt.show()
```


![png](output_7_0.png)



```python
# Build the Cloudiness scatter plot for dataframe
plt.figure(figsize= (12,5))
plt.scatter(df_weather_data["Latitude"], df_weather_data["Cloudiness (%)"], marker="o")

# Incorporate the other graph properties
plt.ylim(-20,120)
plt.xlim(-80,100)
plt.title("City Latitude vs. Cloudiness (06/18/2018)")
plt.ylabel("Cloudiness (%)")
plt.xlabel("Latitude")
plt.grid(True)

# Save the figure
plt.savefig("CityLatitudevsCloudiness.png")

# Show plot
plt.show()
```


![png](output_8_0.png)



```python
# Build the Wind Speed scatter plot for dataframe
plt.figure(figsize= (12,5))
plt.scatter(df_weather_data["Latitude"], df_weather_data["Wind Speed (mph)"], marker="o")

# Incorporate the other graph properties
plt.ylim(-5,40)
plt.xlim(-80,100)
plt.title("City Latitude vs. Wind Speed (06/18/2018)")
plt.ylabel("Wind Speed (mph)")
plt.xlabel("Latitude")
plt.grid(True)

# Save the figure
plt.savefig("CityLatitudevsWindSpeed.png")

# Show plot
plt.show()
```


![png](output_9_0.png)

